// Products module: renders featured and product grid, handles filters and sorting
const Products = (function () {
  let products = [];

  async function load() {
    if (products.length) return products;
    products = await Utils.fetchJSON('/data/products.json');
    return products;
  }

  // Render a product card (used in featured and grid)
  function productCardHTML(p) {
    return `
      <article class="border rounded overflow-hidden bg-white">
        <a href="product.html?id=${encodeURIComponent(p.id)}" class="block">
          <img src="${p.images[0]}" alt="${p.title}" class="w-full h-48 object-cover" loading="lazy" />
          <div class="p-3">
            <h3 class="text-sm font-medium">${p.title}</h3>
            <p class="text-sm text-gray-600 mt-1">${p.category}</p>
            <div class="mt-2 font-semibold">${Utils.formatPrice(p.price,p.currency)}</div>
          </div>
        </a>
      </article>
    `;
  }

  // Render featured products into selector
  async function renderFeatured(selector, limit = 8) {
    const list = document.querySelector(selector);
    if (!list) return;
    const data = await load();
    const featured = data.slice(0, limit);
    list.innerHTML = featured.map(productCardHTML).join('');
  }

  // Initialize products list page
  async function initList({ gridSelector, categorySelector, sortSelector }) {
    const grid = document.querySelector(gridSelector);
    const category = document.querySelector(categorySelector);
    const sort = document.querySelector(sortSelector);

    const data = await load();

    function applyFilters() {
      let filtered = data.slice();

      const cat = category ? category.value : 'all';
      if (cat && cat !== 'all') filtered = filtered.filter(p => p.category === cat);

      const sortVal = sort ? sort.value : 'featured';
      if (sortVal === 'low-high') filtered.sort((a,b)=>a.price-b.price);
      if (sortVal === 'high-low') filtered.sort((a,b)=>b.price-a.price);

      grid.innerHTML = filtered.map(productCardHTML).join('');
    }

    if (category) category.addEventListener('change', applyFilters);
    if (sort) sort.addEventListener('change', applyFilters);
    const clear = document.getElementById('clear-filter');
    if (clear && category) clear.addEventListener('click', () => { category.value = 'all'; applyFilters(); });

    // initial
    applyFilters();
  }

  // Expose functions
  return {
    renderFeatured,
    initList,
    load,
    productCardHTML
  };
})();