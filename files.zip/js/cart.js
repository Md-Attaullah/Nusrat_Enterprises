// Cart logic using localStorage. Key: mrc_cart
const Cart = (function () {
  const KEY = 'mrc_cart';

  // Retrieve cart (array of items {id, size, qty})
  function getCart() {
    try {
      const raw = localStorage.getItem(KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      console.error('Failed to parse cart', e);
      return [];
    }
  }

  function saveCart(cart) {
    localStorage.setItem(KEY, JSON.stringify(cart));
  }

  // Add item (merge if same id + size)
  function addToCart(productId, size, qty = 1) {
    const cart = getCart();
    const idx = cart.findIndex(i => i.id === productId && i.size === size);
    if (idx > -1) {
      cart[idx].qty += qty;
    } else {
      cart.push({ id: productId, size, qty });
    }
    saveCart(cart);
  }

  function removeItem(productId, size) {
    let cart = getCart();
    cart = cart.filter(i => !(i.id === productId && i.size === size));
    saveCart(cart);
  }

  function updateQuantity(productId, size, qty) {
    const cart = getCart();
    const idx = cart.findIndex(i => i.id === productId && i.size === size);
    if (idx > -1) {
      cart[idx].qty = Math.max(1, qty);
      saveCart(cart);
    }
  }

  // returns cart enriched with product data
  async function getFullCart() {
    const items = getCart();
    if (!items.length) return [];
    const products = await Utils.fetchJSON('/data/products.json');
    return items.map(it => {
      const p = products.find(x => x.id === it.id);
      return {
        ...it,
        product: p || null,
        unitPrice: p ? p.price : 0,
        currency: p ? p.currency : 'INR',
        title: p ? p.title : ''
      };
    });
  }

  // Render cart UI into container
  async function renderCart(container) {
    const el = document.querySelector(container);
    if (!el) return;
    const full = await getFullCart();
    if (!full.length) {
      el.innerHTML = `<p class="text-gray-600">Your cart is empty. <a href="products.html" class="text-gray-900">Start shopping</a>.</p>`;
      updateCartCountUI();
      return;
    }

    let subtotal = 0;
    const rows = full.map(item => {
      const lineTotal = item.unitPrice * item.qty;
      subtotal += lineTotal;
      return `
        <div class="flex items-center gap-4 border-b py-4" data-id="${item.id}" data-size="${item.size}">
          <img src="${item.product?.images?.[0] || ''}" alt="${item.title}" class="w-24 h-24 object-cover rounded" />
          <div class="flex-1">
            <a href="product.html?id=${encodeURIComponent(item.id)}" class="font-medium">${item.title}</a>
            <div class="text-sm text-gray-600">Size: ${item.size}</div>
            <div class="text-sm text-gray-800 mt-2">${Utils.formatPrice(item.unitPrice, item.currency)}</div>
          </div>
          <div class="flex items-center gap-2">
            <button class="decrease text-gray-600 px-2">−</button>
            <input type="number" class="w-16 border rounded px-2 py-1 qty-input" value="${item.qty}" min="1" />
            <button class="increase text-gray-600 px-2">+</button>
          </div>
          <div class="w-28 text-right font-medium">${Utils.formatPrice(lineTotal, item.currency)}</div>
          <div>
            <button class="remove text-sm text-red-600">Remove</button>
          </div>
        </div>
      `;
    }).join('');

    el.innerHTML = `
      <div>${rows}</div>
      <div class="mt-6 flex items-center justify-end gap-6">
        <div class="text-lg font-medium">Subtotal: ${Utils.formatPrice(subtotal, 'INR')}</div>
        <a href="products.html" class="text-sm text-gray-600">Continue shopping</a>
        <button id="checkout-btn" class="bg-gray-900 text-white px-4 py-2 rounded">Checkout</button>
      </div>
    `;

    // Attach handlers
    el.querySelectorAll('.remove').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const parent = e.target.closest('[data-id]');
        const id = parent.getAttribute('data-id');
        const size = parent.getAttribute('data-size');
        removeItem(id, size);
        renderCart(container);
        updateCartCountUI();
      });
    });

    el.querySelectorAll('.decrease').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const parent = e.target.closest('[data-id]');
        const id = parent.getAttribute('data-id');
        const size = parent.getAttribute('data-size');
        const input = parent.querySelector('.qty-input');
        const val = Math.max(1, Number(input.value || 1) - 1);
        input.value = val;
        updateQuantity(id, size, val);
        renderCart(container);
        updateCartCountUI();
      });
    });

    el.querySelectorAll('.increase').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const parent = e.target.closest('[data-id]');
        const id = parent.getAttribute('data-id');
        const size = parent.getAttribute('data-size');
        const input = parent.querySelector('.qty-input');
        const val = Math.max(1, Number(input.value || 1) + 1);
        input.value = val;
        updateQuantity(id, size, val);
        renderCart(container);
        updateCartCountUI();
      });
    });

    el.querySelectorAll('.qty-input').forEach(input => {
      input.addEventListener('change', (e) => {
        const parent = e.target.closest('[data-id]');
        const id = parent.getAttribute('data-id');
        const size = parent.getAttribute('data-size');
        const val = Math.max(1, Number(e.target.value || 1));
        e.target.value = val;
        updateQuantity(id, size, val);
        renderCart(container);
        updateCartCountUI();
      });
    });

    document.getElementById('checkout-btn')?.addEventListener('click', function () {
      alert('Demo checkout — this site is static. Thank you for shopping!');
    });

    updateCartCountUI();
  }

  function countItems() {
    const cart = getCart();
    return cart.reduce((sum, it) => sum + it.qty, 0);
  }

  function updateCartCountUI() {
    const count = countItems();
    const els = document.querySelectorAll('#cart-count, #cart-count-mobile');
    els.forEach(el => { el.textContent = count; });
  }

  return {
    addToCart,
    removeItem,
    updateQuantity,
    renderCart,
    getCart,
    updateCartCountUI
  };
})();