// Simple client-side validation for contact form (no backend)
document.addEventListener('DOMContentLoaded', function () {
  const form = document.getElementById('contact-form');
  if (!form) return;

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    // simple validation
    const name = form.querySelector('#name');
    const email = form.querySelector('#email');
    const message = form.querySelector('#message');

    let ok = true;
    if (!name.value.trim()) { document.getElementById('name-error').classList.remove('hidden'); ok = false; } else document.getElementById('name-error').classList.add('hidden');
    if (!email.value.trim() || !/^\S+@\S+\.\S+$/.test(email.value)) { document.getElementById('email-error').classList.remove('hidden'); ok = false; } else document.getElementById('email-error').classList.add('hidden');
    if (!message.value.trim()) { document.getElementById('message-error').classList.remove('hidden'); ok = false; } else document.getElementById('message-error').classList.add('hidden');

    if (!ok) return;
    // Demo: no backend — show success and clear
    document.getElementById('contact-success').classList.remove('hidden');
    form.reset();
    setTimeout(()=>document.getElementById('contact-success').classList.add('hidden'), 5000);
  });
});