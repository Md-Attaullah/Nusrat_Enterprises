// Utilities used across pages: fetch JSON, format currency, read query params
const Utils = (function () {
  async function fetchJSON(path) {
    const res = await fetch(path, { cache: "no-cache" });
    if (!res.ok) throw new Error('Failed to load ' + path);
    return res.json();
  }

  function formatPrice(amount, currency = 'INR') {
    // Format INR with rupee symbol
    if (currency === 'INR') {
      return `₹${amount.toLocaleString('en-IN')}`;
    }
    return amount;
  }

  function getParam(name) {
    const url = new URL(window.location.href);
    return url.searchParams.get(name);
  }

  return {
    fetchJSON,
    formatPrice,
    getParam
  };
})();