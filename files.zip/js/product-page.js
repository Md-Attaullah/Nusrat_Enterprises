// Product page logic: reads ?id=, renders gallery, size selector, add to cart
const ProductPage = (function () {
  let product = null;

  function galleryHTML(images) {
    if (!images || !images.length) return '';
    const thumbs = images.map((src,i)=>`<button data-idx="${i}" class="border rounded overflow-hidden mr-2"><img src="${src}" alt="image ${i+1}" class="w-20 h-20 object-cover" loading="lazy"/></button>`).join('');
    return `
      <div>
        <img id="main-image" src="${images[0]}" alt="product image" class="w-full h-96 object-cover rounded" />
        <div class="mt-3 flex">${thumbs}</div>
      </div>
    `;
  }

  async function render(container) {
    const id = Utils.getParam('id');
    if (!id) {
      document.querySelector(container).innerHTML = '<p>Product not found.</p>';
      return;
    }
    const products = await Products.load();
    product = products.find(p => p.id === id);
    if (!product) {
      document.querySelector(container).innerHTML = '<p>Product not found.</p>';
      return;
    }

    const html = `
      <div class="col-span-1">
        ${galleryHTML(product.images)}
      </div>
      <div>
        <h1 class="text-2xl font-semibold">${product.title}</h1>
        <p class="text-sm text-gray-600 mt-1">${product.category}</p>
        <div class="mt-4 text-xl font-bold">${Utils.formatPrice(product.price, product.currency)}</div>

        <form id="add-to-cart-form" class="mt-6 space-y-4" aria-labelledby="add-to-cart">
          <div>
            <label class="block text-sm font-medium">Size</label>
            <div class="mt-2 flex gap-2" id="size-options">
              ${product.sizes.map(s=>`<label class="inline-flex items-center px-3 py-2 border rounded cursor-pointer"><input type="radio" name="size" value="${s}" class="sr-only" ${s==='M'?'checked':''} /><span>${s}</span></label>`).join('')}
            </div>
          </div>
          <div>
            <label for="qty" class="block text-sm font-medium">Quantity</label>
            <input id="qty" name="qty" type="number" min="1" value="1" class="mt-1 w-24 border rounded px-3 py-2" />
          </div>
          <div>
            <button type="submit" class="bg-gray-900 text-white px-4 py-2 rounded">Add to cart</button>
            <a href="products.html" class="ml-3 text-sm text-gray-600">Continue shopping</a>
          </div>
        </form>

        <div class="mt-6 text-gray-700">
          <h3 class="font-medium">Details</h3>
          <p class="mt-2 text-sm">${product.description}</p>
        </div>
      </div>
    `;

    document.querySelector(container).innerHTML = html;

    // add gallery click handlers
    const thumbButtons = document.querySelectorAll('[data-idx]');
    thumbButtons.forEach(btn => btn.addEventListener('click', (e) => {
      const i = Number(btn.getAttribute('data-idx'));
      document.getElementById('main-image').src = product.images[i];
    }));

    // form submit -> add to cart
    document.getElementById('add-to-cart-form').addEventListener('submit', function (e) {
      e.preventDefault();
      const sizeInput = document.querySelector('input[name="size"]:checked');
      const size = sizeInput ? sizeInput.value : null;
      const qty = Math.max(1, Number(document.getElementById('qty').value || 1));
      if (!size) {
        alert('Please select a size.');
        return;
      }
      Cart.addToCart(product.id, size, qty);
      // simple feedback
      alert('Added to cart');
      Cart.updateCartCountUI();
    });
  }

  return {
    init: function () { render('#product-detail'); }
  };
})();